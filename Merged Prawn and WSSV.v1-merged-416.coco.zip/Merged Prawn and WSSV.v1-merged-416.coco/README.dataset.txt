# Merged Prawn and WSSV > Merged 416
https://universe.roboflow.com/prawn-detection/merged-prawn-and-wssv

Provided by a Roboflow user
License: CC BY 4.0

